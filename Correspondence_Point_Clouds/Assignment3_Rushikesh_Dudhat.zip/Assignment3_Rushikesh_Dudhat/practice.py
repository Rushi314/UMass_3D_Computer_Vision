import torch

input1 = torch.tensor([[1.0, 5.0],
                       [3.0, 4.0],
                       [7.0, 1.0]])
input2 = torch.tensor([1.0, 2.0])
pt_s, ind = torch.max(input1, dim=0)
# print(torch.((input1,input2[0]),dim=1))
new = torch.cat(3 * [input2])
print(torch.max(input1, dim=0))
# print(torch.column_stack((input1,new)))

def sim_matri(a, b, eps=1e-8):
    """
    added eps for numerical stability
    """
    a_n, b_n = a.norm(dim=1)[:, None], b.norm(dim=1)[:, None]
    a_norm = a / torch.max(a_n, eps * torch.ones_like(a_n))
    b_norm = b / torch.max(b_n, eps * torch.ones_like(b_n))
    sim_mt = torch.mm(a_norm, b_norm.transpose(0, 1))
    return sim_mt
input1 = torch.randn(3, 3)
input2 = torch.randn(3, 1)
print(input2.shape)
print(torch.cat((input2, input1),dim=1))